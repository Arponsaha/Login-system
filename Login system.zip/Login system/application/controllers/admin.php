<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {

	public function index()

	{
		$this->load->view('welcome_message');
	}

	

		public function arpon()
		{
			$this->load->view('pages/arpon');
		}

		public function poper()
		{
			$this->load->view('pages/poper');
		}
	
	
	public function login(){
		$data['admin_main_content']=$this->load->view('pages/page1','',true);
		$this->load->view('pages/login',$data);
	}


    
	public function admin_login()
	{
        $data=array();
        $data['admin_main_content']=$this->load->view('pages/page1','',true);
		$this->load->view('dashboard',$data);
	}

    public function sms_login(){
        var_dump("Hello"); 
        die(); 
    }
}