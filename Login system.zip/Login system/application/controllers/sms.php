<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class sms extends CI_Controller {

	public function sms_login()
	{
		echo 'arpon';
	}

	
}